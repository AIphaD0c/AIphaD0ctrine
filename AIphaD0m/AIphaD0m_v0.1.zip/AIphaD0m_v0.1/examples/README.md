# Example

`synthetic_concert.mp4` is a generated technical test fixture. It is not a model of a real performance.

```bash
aiphad0m examples/synthetic_concert.mp4 --output output/demo
```
