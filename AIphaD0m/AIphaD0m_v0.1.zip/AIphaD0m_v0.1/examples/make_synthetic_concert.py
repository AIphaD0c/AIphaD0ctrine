from pathlib import Path
import cv2, numpy as np, soundfile as sf

out = Path(__file__).resolve().parent / "synthetic_concert.mp4"
wav = out.with_suffix('.wav')
fps, seconds, w, h, sr = 15, 48, 480, 270, 22050
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
video = cv2.VideoWriter(str(out.with_name('silent.mp4')), fourcc, fps, (w,h))
rng = np.random.default_rng(7)
for i in range(fps*seconds):
    t=i/fps
    if t<7: e=.08
    elif t<16: e=.30
    elif t<29: e=.35+(t-16)/22
    elif t<34: e=.10
    elif t<42: e=.95
    else: e=.22
    frame=np.zeros((h,w,3),np.uint8)
    base=int(10+100*e)
    frame[:]=base
    # stage horizon + performer hands in POV
    cv2.rectangle(frame,(0,int(h*.58)),(w,h),(int(base*.5),)*3,-1)
    swing=int(30*np.sin(t*2.2))
    cv2.line(frame,(w//2-55+swing,h),(w//2-25+swing,int(h*.58)),(170,170,170),18)
    cv2.line(frame,(w//2+55-swing,h),(w//2+25-swing,int(h*.58)),(170,170,170),18)
    n=int(15+170*e)
    for _ in range(n):
        x=int(rng.integers(0,w)); y=int(rng.integers(int(h*.25),int(h*.57)))
        cv2.circle(frame,(x,y),1+(e>.8), (220,220,220),-1)
    if 29<t<34: frame//=5
    if 34<t<42 and i%5==0: frame[:]=230
    video.write(frame)
video.release()
t=np.arange(seconds*sr)/sr
env=np.piecewise(t,[t<7,(t>=7)&(t<16),(t>=16)&(t<29),(t>=29)&(t<34),(t>=34)&(t<42),t>=42],[.05,.25,lambda x:.3+.035*(x-16),.03,.95,.15])
y=env*(.55*np.sin(2*np.pi*110*t)+.3*np.sin(2*np.pi*220*t))
y += env*.04*rng.standard_normal(len(t))
sf.write(wav,y,sr)
print(out)
