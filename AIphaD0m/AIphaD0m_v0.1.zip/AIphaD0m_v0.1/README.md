# AIphaD0m v0.1 — First Software Release

> The tool was made.  
> The domain emerged.

AIphaD0m v0.1 is a local-first audiovisual analysis engine. It converts a licensed local video into a machine-readable **experience timeline** rather than merely describing the source recording.

## What v0.1 produces

- audiovisual feature windows
- a normalized tension curve
- dramaturgical phases
- transparent narrative identity states
- a first-person direction score
- a memory timeline
- JSON, CSV and standalone HTML outputs

It does **not** identify faces, infer real psychological states, clone a performer, upload media, or call a cloud API.

## Install

Python 3.10 or newer and FFmpeg are recommended.

```bash
cd AIphaD0m
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

Windows activation:

```powershell
.venv\Scripts\activate
```

## Verify the installation

```bash
pytest
```

## Run the included example

```bash
aiphad0m examples/synthetic_concert.mp4 --output output/demo
```

Open `output/demo/report.html`.

## Analyze another video

```bash
aiphad0m /path/to/licensed-video.mp4 --output output/my-session --window 2
```

Outputs:

```text
experience.json   complete v0.1 schema
memory.json       compact memory timeline
timeline.csv      analysis windows
report.html       human-readable visualization
```

## Current interpretation boundary

`identity_state` is a control state for interactive narrative design:

```text
observer
embodiment_transition
aiphad0c_lock
identity_residue
```

It is not a diagnosis or a claim about the viewer's mind.

## v0.1 architecture

```text
licensed local video
        │
        ├── VisionAgent
        ├── AudioAgent
        │
        ▼
    FusionAgent
        │
        ├── DramaturgyAgent
        ├── IdentityAgent
        ├── DirectionAgent
        └── MemoryAgent
        │
        ▼
AIphaD0m.experience/0.1
```

## Next release

v0.2 should add semantic crowd, stage, performer-body and gaze events while preserving local-first operation and explicit provenance.
