from pathlib import Path

from aiphad0m import AIphaD0m


def test_synthetic_video(tmp_path: Path) -> None:
    video = Path(__file__).parents[1] / "examples" / "synthetic_concert.mp4"
    report = AIphaD0m(window_s=2.0).analyze(video, tmp_path)
    assert report["schema"] == "AIphaD0m.experience/0.1"
    assert report["duration_seconds"] > 0
    assert report["windows"]
    assert report["memory_timeline"]
    assert (tmp_path / "experience.json").exists()
    assert (tmp_path / "memory.json").exists()
    assert (tmp_path / "report.html").exists()
