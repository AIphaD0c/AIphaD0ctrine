# Changelog

## 0.1.0 — First Embodiment

- Added installable `aiphad0m` Python package.
- Added local video analysis CLI.
- Added audiovisual feature fusion and tension timeline.
- Added dramaturgy, identity, direction and memory agents.
- Added `AIphaD0m.experience/0.1` JSON schema output.
- Added CSV and standalone HTML reports.
- Added synthetic test video and automated test.
