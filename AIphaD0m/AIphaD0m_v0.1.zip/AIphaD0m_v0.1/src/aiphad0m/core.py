from __future__ import annotations

import csv
import json
import math
import subprocess
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import cv2
import librosa
import numpy as np


@dataclass
class ExperienceWindow:
    start: float
    end: float
    audio_rms: float
    audio_onset: float
    brightness: float
    motion: float
    cut_rate: float
    visual_complexity: float
    tension: float = 0.0
    dramaturgy: str = ""
    identity_state: str = "observer"
    embodiment: float = 0.0


class AudioAgent:
    def analyze(self, audio_path: Path, duration: float, window_s: float) -> list[tuple[float, float]]:
        count = max(1, math.ceil(duration / window_s))
        try:
            y, sr = librosa.load(str(audio_path), sr=22050, mono=True)
        except Exception:
            return [(0.0, 0.0)] * count
        if y.size == 0:
            return [(0.0, 0.0)] * count
        hop = 512
        rms = librosa.feature.rms(y=y, hop_length=hop)[0]
        onset = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop)
        times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop)
        out: list[tuple[float, float]] = []
        for start in np.arange(0, duration, window_s):
            mask = (times >= start) & (times < start + window_s)
            out.append((
                float(np.mean(rms[mask])) if mask.any() else 0.0,
                float(np.mean(onset[mask])) if mask.any() else 0.0,
            ))
        return out


class VisionAgent:
    def analyze(self, video_path: Path, window_s: float) -> tuple[float, list[dict[str, float]]]:
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            raise ValueError(f"Unable to open video: {video_path}")
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = frames / fps if frames else 0.0
        sample_every = max(1, int(round(fps / 5.0)))
        buckets: dict[int, list[tuple[float, float, float, float]]] = {}
        prev_gray = None
        prev_hist = None
        idx = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if idx % sample_every:
                idx += 1
                continue
            t = idx / fps
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            small = cv2.resize(gray, (96, 54))
            brightness = float(np.mean(small) / 255.0)
            motion = 0.0 if prev_gray is None else float(np.mean(cv2.absdiff(small, prev_gray)) / 255.0)
            hist = cv2.calcHist([small], [0], None, [32], [0, 256])
            cv2.normalize(hist, hist)
            cut = 0.0 if prev_hist is None else float(
                cv2.compareHist(prev_hist, hist, cv2.HISTCMP_BHATTACHARYYA) > 0.42
            )
            edges = cv2.Canny(small, 70, 150)
            complexity = float(np.mean(edges > 0))
            bucket = int(t // window_s)
            buckets.setdefault(bucket, []).append((brightness, motion, cut, complexity))
            prev_gray, prev_hist = small, hist
            idx += 1
        cap.release()
        count = max(1, math.ceil(duration / window_s))
        rows: list[dict[str, float]] = []
        for bucket in range(count):
            values = np.asarray(buckets.get(bucket, [(0.0, 0.0, 0.0, 0.0)]))
            rows.append({
                "brightness": float(values[:, 0].mean()),
                "motion": float(values[:, 1].mean()),
                "cut_rate": float(values[:, 2].mean()),
                "visual_complexity": float(values[:, 3].mean()),
            })
        return duration, rows


class FusionAgent:
    @staticmethod
    def normalize(values: Iterable[float]) -> np.ndarray:
        x = np.asarray(list(values), dtype=float)
        lo, hi = np.percentile(x, 5), np.percentile(x, 95)
        if hi <= lo + 1e-9:
            return np.zeros_like(x)
        return np.clip((x - lo) / (hi - lo), 0, 1)

    def apply(self, windows: list[ExperienceWindow]) -> None:
        signals = {
            "rms": self.normalize(w.audio_rms for w in windows),
            "onset": self.normalize(w.audio_onset for w in windows),
            "motion": self.normalize(w.motion for w in windows),
            "cuts": self.normalize(w.cut_rate for w in windows),
            "brightness": self.normalize(w.brightness for w in windows),
            "complexity": self.normalize(w.visual_complexity for w in windows),
        }
        raw = (
            0.30 * signals["rms"] + 0.18 * signals["onset"]
            + 0.18 * signals["motion"] + 0.14 * signals["cuts"]
            + 0.10 * signals["brightness"] + 0.10 * signals["complexity"]
        )
        smooth = np.convolve(raw, np.ones(3) / 3, mode="same") if len(raw) >= 3 else raw
        for index, window in enumerate(windows):
            window.tension = round(float(smooth[index]), 4)


class DramaturgyAgent:
    def apply(self, windows: list[ExperienceWindow]) -> None:
        if not windows:
            return
        values = np.asarray([w.tension for w in windows])
        peak = int(np.argmax(values))
        false_ending = None
        for index in range(2, peak):
            if (
                values[index] < values[index - 1]
                and values[index] < values[index - 2]
                and values[index] < np.quantile(values, 0.45)
            ):
                false_ending = index
        total = len(windows)
        for index, window in enumerate(windows):
            position = index / max(1, total - 1)
            if index == peak:
                phase = "collective_climax"
            elif false_ending is not None and abs(index - false_ending) <= 1:
                phase = "void_or_false_ending"
            elif position < 0.15:
                phase = "anticipation"
            elif position < 0.35:
                phase = "first_reveal"
            elif index < peak:
                phase = "scale_expansion"
            elif position > 0.88:
                phase = "afterimage"
            else:
                phase = "release"
            window.dramaturgy = phase


class IdentityAgent:
    """Maps audiovisual intensity to a transparent identity-state hypothesis."""

    def apply(self, windows: list[ExperienceWindow]) -> None:
        for window in windows:
            embodiment = np.clip(
                0.48 * window.tension
                + 0.22 * min(1.0, window.motion * 5.0)
                + 0.18 * min(1.0, window.audio_onset / 10.0)
                + 0.12 * min(1.0, window.visual_complexity * 5.0),
                0.0,
                1.0,
            )
            window.embodiment = round(float(embodiment), 4)
            if window.dramaturgy == "afterimage":
                state = "identity_residue"
            elif embodiment >= 0.68:
                state = "aiphad0c_lock"
            elif embodiment >= 0.40:
                state = "embodiment_transition"
            else:
                state = "observer"
            window.identity_state = state


class MemoryAgent:
    LABELS = {
        "anticipation": "The body waits before the signal.",
        "first_reveal": "The near crowd appears before the scale is understood.",
        "scale_expansion": "The domain expands beyond the visible stage.",
        "void_or_false_ending": "The signal withdraws but the body remains.",
        "collective_climax": "The crowd behaves as one organism.",
        "release": "Control decreases. Identity remains active.",
        "afterimage": "The event ends. The memory continues.",
    }

    def build(self, windows: list[ExperienceWindow]) -> list[dict[str, object]]:
        memories: list[dict[str, object]] = []
        last_phase = None
        last_identity = None
        for window in windows:
            changed = window.dramaturgy != last_phase or window.identity_state != last_identity
            if changed:
                memories.append({
                    "time": round(window.start, 2),
                    "phase": window.dramaturgy,
                    "identity_state": window.identity_state,
                    "embodiment": window.embodiment,
                    "memory": self.LABELS[window.dramaturgy],
                })
                last_phase = window.dramaturgy
                last_identity = window.identity_state
        return memories


class DirectionAgent:
    ACTIONS = {
        "anticipation": "Dark backstage POV; breathing and footfalls dominate; hands only partly visible.",
        "first_reveal": "Enter the stage; expose the near crowd first, then reveal scale through gaze movement.",
        "scale_expansion": "Gestures alter light and crowd response; preserve stable first-person anatomy.",
        "void_or_false_ending": "Remove PA weight, freeze crowd motion, retain heartbeat and in-ear residue.",
        "collective_climax": "The crowd reacts as one organism; the user's arms conduct the response.",
        "release": "Reduce cut density; permit delayed reflections and impossible familiarity.",
        "afterimage": "Music ends but embodiment continues; reflection moves after the user stops.",
    }

    def build(self, windows: list[ExperienceWindow]) -> list[dict[str, object]]:
        score: list[dict[str, object]] = []
        last = None
        for window in windows:
            if window.dramaturgy != last:
                score.append({
                    "start": round(window.start, 2),
                    "phase": window.dramaturgy,
                    "identity_state": window.identity_state,
                    "direction": self.ACTIONS[window.dramaturgy],
                    "target_tension": window.tension,
                })
                last = window.dramaturgy
        return score


class AIphaD0m:
    def __init__(self, window_s: float = 2.0):
        if window_s <= 0:
            raise ValueError("window_s must be positive")
        self.window_s = window_s
        self.audio = AudioAgent()
        self.vision = VisionAgent()
        self.fusion = FusionAgent()
        self.dramaturgy = DramaturgyAgent()
        self.identity = IdentityAgent()
        self.memory = MemoryAgent()
        self.direction = DirectionAgent()

    @staticmethod
    def extract_audio(video_path: Path, output_wav: Path) -> bool:
        command = [
            "ffmpeg", "-y", "-loglevel", "error", "-i", str(video_path),
            "-vn", "-ac", "1", "-ar", "22050", str(output_wav),
        ]
        try:
            subprocess.run(command, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def analyze(self, video_path: Path, output_dir: Path) -> dict[str, object]:
        video_path = Path(video_path)
        output_dir = Path(output_dir)
        if not video_path.exists():
            raise FileNotFoundError(video_path)
        output_dir.mkdir(parents=True, exist_ok=True)
        duration, visual = self.vision.analyze(video_path, self.window_s)
        with tempfile.TemporaryDirectory() as directory:
            wav = Path(directory) / "audio.wav"
            audio = (
                self.audio.analyze(wav, duration, self.window_s)
                if self.extract_audio(video_path, wav)
                else [(0.0, 0.0)] * len(visual)
            )
        windows: list[ExperienceWindow] = []
        for index, vision in enumerate(visual):
            audio_values = audio[index] if index < len(audio) else (0.0, 0.0)
            windows.append(ExperienceWindow(
                start=index * self.window_s,
                end=min(duration, (index + 1) * self.window_s),
                audio_rms=audio_values[0],
                audio_onset=audio_values[1],
                **vision,
            ))
        self.fusion.apply(windows)
        self.dramaturgy.apply(windows)
        self.identity.apply(windows)
        direction = self.direction.build(windows)
        memories = self.memory.build(windows)
        report: dict[str, object] = {
            "schema": "AIphaD0m.experience/0.1",
            "source": str(video_path),
            "duration_seconds": round(duration, 2),
            "window_seconds": self.window_s,
            "windows": [asdict(window) for window in windows],
            "direction_score": direction,
            "memory_timeline": memories,
            "limitations": [
                "v0.1 derives hypotheses from low-level audiovisual signals; it does not identify people.",
                "Identity states are narrative control states, not psychological measurements.",
                "Only analyze media for which the required rights and permissions exist.",
            ],
        }
        self._write_outputs(report, output_dir)
        return report

    def _write_outputs(self, report: dict[str, object], output_dir: Path) -> None:
        (output_dir / "experience.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        windows = report["windows"]
        if windows:
            with (output_dir / "timeline.csv").open("w", newline="", encoding="utf-8") as file:
                writer = csv.DictWriter(file, fieldnames=list(windows[0].keys()))
                writer.writeheader()
                writer.writerows(windows)
        (output_dir / "memory.json").write_text(
            json.dumps(report["memory_timeline"], indent=2), encoding="utf-8"
        )
        self._write_html(report, output_dir / "report.html")

    @staticmethod
    def _write_html(report: dict[str, object], path: Path) -> None:
        rows = report["windows"]
        maximum = max((row["tension"] for row in rows), default=1) or 1
        bars = "".join(
            f'<div class="bar" title="{row["start"]:.0f}s · {row["dramaturgy"]} · {row["identity_state"]}" '
            f'style="height:{12 + 120 * row["tension"] / maximum:.0f}px"></div>'
            for row in rows
        )
        memory = "".join(
            f'<li><b>{item["time"]:.0f}s — {item["phase"]}</b><br>'
            f'{item["memory"]}<br><small>{item["identity_state"]} · embodiment {item["embodiment"]:.2f}</small></li>'
            for item in report["memory_timeline"]
        )
        html = f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AIphaD0m v0.1</title>
<style>body{{font:16px system-ui;margin:40px auto;max-width:1050px;padding:0 20px;background:#0b0b0b;color:#eee}}h1{{letter-spacing:.08em}}.chart{{height:170px;display:flex;align-items:end;gap:3px;border-bottom:1px solid #666}}.bar{{flex:1;background:#aaa;min-width:3px}}li{{margin:18px 0;line-height:1.5}}small{{color:#aaa}}code{{background:#222;padding:.15em .35em}}</style></head><body>
<h1>AIphaD0m v0.1</h1><p>The domain emerged.</p><small>{report["source"]} · {report["duration_seconds"]} s · schema <code>{report["schema"]}</code></small>
<h2>Tension timeline</h2><div class="chart">{bars}</div><h2>Memory timeline</h2><ol>{memory}</ol></body></html>'''
        path.write_text(html, encoding="utf-8")
