from __future__ import annotations

import argparse
from pathlib import Path

from .core import AIphaD0m


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="aiphad0m",
        description="Transform a licensed local video into an AIphaD0m experience timeline.",
    )
    parser.add_argument("video", type=Path, help="Local video file")
    parser.add_argument("--output", "-o", type=Path, default=Path("output"))
    parser.add_argument("--window", type=float, default=2.0, help="Analysis window in seconds")
    args = parser.parse_args()
    try:
        report = AIphaD0m(window_s=args.window).analyze(args.video, args.output)
    except (FileNotFoundError, ValueError) as error:
        parser.error(str(error))
    print(f"AIphaD0m analyzed {report['duration_seconds']} s")
    print(f"Experience: {args.output / 'experience.json'}")
    print(f"Memory:     {args.output / 'memory.json'}")
    print(f"Report:     {args.output / 'report.html'}")


if __name__ == "__main__":
    main()
