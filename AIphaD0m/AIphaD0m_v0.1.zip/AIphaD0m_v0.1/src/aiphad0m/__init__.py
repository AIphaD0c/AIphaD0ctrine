"""AIphaD0m — the domain emerged."""

from .core import AIphaD0m

__all__ = ["AIphaD0m"]
__version__ = "0.1.0"
